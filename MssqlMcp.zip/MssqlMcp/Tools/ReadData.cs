// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

using System.ComponentModel;
using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using ModelContextProtocol.Server;

namespace Mssql.McpServer;

public partial class Tools
{
    private static readonly Regex SingleStatementRegex =
        new(@"^\s*(WITH\s+[\s\S]+?SELECT|SELECT)\s+[\s\S]+?$",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

    [McpServerTool(
        Title = "Read Data",
        ReadOnly = true,
        Idempotent = true,
        Destructive = false),
     Description(
        "Executes a READ-ONLY SQL query (SELECT/WITH only).\n" +
        "IMPORTANT: You MUST call 'Retrieve Knowledge' first and pass its knowledgeToken here. " +
        "If you do not, this tool will fail.\n" +
        "The SQL must be a single SELECT (or WITH..SELECT) statement."
     )]
    public async Task<DbOperationResult> ReadData(
        [Description("SQL query to execute. Must be a single SELECT (or WITH..SELECT).")]
        string sql,
        [Description("Knowledge token returned by 'Retrieve Knowledge'. REQUIRED. Call Retrieve Knowledge first.")]
        string knowledgeToken)
    {
        // 1) Hard guard: token skal være til stede
        if (string.IsNullOrWhiteSpace(knowledgeToken))
        {
            return new DbOperationResult(
                success: false,
                error: "Missing knowledgeToken. You MUST call 'Retrieve Knowledge' first, then pass its token to Read Data."
            );
        }

        // 2) Hard guard: token skal være gyldigt (registreret + ikke udløbet)
        if (!KnowledgeSessionManager.IsValid(knowledgeToken))
        {
            return new DbOperationResult(
                success: false,
                error: "Invalid or expired knowledgeToken. Call 'Retrieve Knowledge' again to obtain a fresh token before using Read Data."
            );
        }

        // 3) SQL-validation
        if (string.IsNullOrWhiteSpace(sql) || !SingleStatementRegex.IsMatch(sql))
        {
            return new DbOperationResult(
                success: false,
                error: "Read Data only allows a single SELECT (or WITH..SELECT) statement."
            );
        }

        var conn = await _connectionFactory.GetOpenConnectionAsync();
        try
        {
            using (conn)
            using (var cmd = new SqlCommand(sql, conn))
            using (var reader = await cmd.ExecuteReaderAsync())
            {
                var results = new List<Dictionary<string, object?>>();
                while (await reader.ReadAsync())
                {
                    var row = new Dictionary<string, object?>();
                    for (var i = 0; i < reader.FieldCount; i++)
                    {
                        row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    results.Add(row);
                }

                return new DbOperationResult(success: true, data: results);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "ReadData failed: {Message}", ex.Message);
            return new DbOperationResult(success: false, error: ex.Message);
        }
    }
}
