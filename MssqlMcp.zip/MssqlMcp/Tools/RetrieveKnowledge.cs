// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

using System.ComponentModel;
using ModelContextProtocol.Server;

namespace Mssql.McpServer;

public partial class Tools
{
    [McpServerTool(
        Title = "Retrieve Knowledge",
        ReadOnly = true,
        Idempotent = true,
        Destructive = false),
     Description(
        "Retrieves domain/business knowledge from the Knowledge base.\n" +
        "You MUST call this tool before calling any database tools.\n" +
        "It returns a knowledgeToken which MUST be passed into List Tables, Describe Table, Read Data, etc."
     )]
    public Task<DbOperationResult> RetrieveKnowledge(
        [Description("Query text to search in the knowledge base (ex: 'sales in EUR vs LCY', 'country currency rules').")]
        string query)
    {
        if (string.IsNullOrWhiteSpace(query))
        {
            return Task.FromResult(
                new DbOperationResult(
                    success: false,
                    error: "Query is empty. Provide a query so I can retrieve relevant knowledge."
                )
            );
        }

        // Brug den eksisterende knowledge base til semantisk søgning
        string? knowledge = _knowledgeBase.Search(query);

        if (string.IsNullOrWhiteSpace(knowledge))
        {
            // Ingen relevant knowledge fundet – vi udsteder stadig et token,
            // så LLM kan fortsætte og ved, at der ikke var noget at hente.
            var emptyKnowledge = string.Empty;
            var emptyToken = KnowledgeSessionManager.RegisterToken(emptyKnowledge);

            var emptyPayload = new
            {
                knowledgeToken = emptyToken,
                knowledge = emptyKnowledge,
                message = "No relevant knowledge found for the query."
            };

            return Task.FromResult(
                new DbOperationResult(success: true, data: emptyPayload)
            );
        }

        // Vi har fundet knowledge – registrér token via KnowledgeSessionManager
        var token = KnowledgeSessionManager.RegisterToken(knowledge);

        var payload = new
        {
            knowledgeToken = token,
            knowledge = knowledge
        };

        return Task.FromResult(
            new DbOperationResult(success: true, data: payload)
        );
    }
}
