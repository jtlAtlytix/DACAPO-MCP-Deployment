// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

// KnowledgeLoader.cs
//
// Utility til at læse rå knowledge-tekster fra Knowledge/-mappen.
// Bruges når vi vil injicere en statisk summary eller hente specifikke filer.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Mssql.McpServer;

/// <summary>
/// Helper til at læse *.txt-filerne i Knowledge/-mappen.
/// Gør det nemt at bygge en samlet tekstblok eller hente enkelte filer,
/// som kan injiceres i prompts.
/// (Semantisk søgning håndteres stadig af KnowledgeBase, dette er "raw I/O").
/// </summary>
public static class KnowledgeLoader
{
    private static string KnowledgeDirectory =>
        Path.Combine(AppContext.BaseDirectory, "Knowledge");

    /// <summary>
    /// Læser alle *.txt-filer i Knowledge/-mappen og concatenerer dem
    /// til én stor tekstblok, med et simpelt "### filnavn" header pr. fil.
    /// Velegnet til fx initial system-prompt eller debugging.
    /// </summary>
    public static string LoadAllAsSingleBlock()
    {
        if (!Directory.Exists(KnowledgeDirectory))
        {
            return string.Empty;
        }

        var sb = new StringBuilder();

        var files = Directory
            .GetFiles(KnowledgeDirectory, "*.txt", SearchOption.TopDirectoryOnly)
            .OrderBy(f => f, StringComparer.OrdinalIgnoreCase);

        foreach (var file in files)
        {
            var name = Path.GetFileName(file);
            var content = File.ReadAllText(file);

            sb.AppendLine($"### {name}");
            sb.AppendLine(content.Trim());
            sb.AppendLine();
        }

        return sb.ToString().Trim();
    }

    /// <summary>
    /// Læser indholdet af én specifik knowledge-fil (fx "knowledge_tables.txt").
    /// Returnerer tom streng hvis filen ikke findes.
    /// </summary>
    public static string LoadFile(string fileName)
    {
        if (string.IsNullOrWhiteSpace(fileName))
        {
            return string.Empty;
        }

        var fullPath = Path.Combine(KnowledgeDirectory, fileName);

        if (!File.Exists(fullPath))
        {
            return string.Empty;
        }

        return File.ReadAllText(fullPath);
    }
}
