// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

using System;
using System.Collections.Generic;
using System.IO;

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

namespace Mssql.McpServer;



/// <summary>
/// Simpel vidensbase der indlæser tekstfiler fra Knowledge/-mappen,
/// opdeler dem i chunks og laver dummy-embeddings til semantisk søgning.
/// </summary>
public class KnowledgeBase
{
    private readonly List<KnowledgeChunk> _knowledgeChunks = new();

    private sealed class KnowledgeChunk
    {
        public string Text { get; }
        public float[] Embedding { get; }

        public KnowledgeChunk(string text, float[] embedding)
        {
            Text = text;
            Embedding = embedding;
        }
    }

    public KnowledgeBase()
    {
        string baseDir = AppContext.BaseDirectory;
        string knowledgePath = Path.Combine(baseDir, "Knowledge");

        if (!Directory.Exists(knowledgePath))
        {
            Directory.CreateDirectory(knowledgePath);
        }

        string[] files = Directory.GetFiles(
            knowledgePath,
            "*.txt",
            SearchOption.TopDirectoryOnly
        );

        foreach (string file in files)
        {
            string content = File.ReadAllText(file);

            foreach (string chunk in ChunkText(content, maxLength: 200))
            {
                if (!string.IsNullOrWhiteSpace(chunk))
                {
                    float[] vector = EmbedText(chunk);
                    _knowledgeChunks.Add(new KnowledgeChunk(chunk.Trim(), vector));
                }
            }
        }
    }

    private static float[] EmbedText(string text)
    {
        const int vectorSize = 64;
        float[] embedding = new float[vectorSize];

        int seed = text.GetHashCode();
        var rand = new Random(seed);

        for (int i = 0; i < vectorSize; i++)
        {
            embedding[i] = (float)rand.NextDouble();
        }

        return embedding;
    }

    public string? Search(string query)
    {
        if (string.IsNullOrWhiteSpace(query) || _knowledgeChunks.Count == 0)
        {
            return null;
        }

        float[] queryVector = EmbedText(query);

        double queryNorm = 0;
        for (int i = 0; i < queryVector.Length; i++)
        {
            queryNorm += queryVector[i] * queryVector[i];
        }
        queryNorm = Math.Sqrt(queryNorm);

        double bestScore = -1.0;
        string? bestMatchText = null;

        foreach (var chunk in _knowledgeChunks)
        {
            float[] vector = chunk.Embedding;

            double dot = 0;
            double chunkNorm = 0;

            for (int i = 0; i < vector.Length; i++)
            {
                dot += queryVector[i] * vector[i];
                chunkNorm += vector[i] * vector[i];
            }

            chunkNorm = Math.Sqrt(chunkNorm);
            if (chunkNorm == 0 || queryNorm == 0)
            {
                continue;
            }

            double cosSim = dot / (queryNorm * chunkNorm);

            if (cosSim > bestScore)
            {
                bestScore = cosSim;
                bestMatchText = chunk.Text;
            }
        }

        return bestMatchText;
    }

    private static IEnumerable<string> ChunkText(string text, int maxLength)
    {
        if (string.IsNullOrEmpty(text))
        {
            yield break;
        }

        int index = 0;

        while (index < text.Length)
        {
            int length = Math.Min(maxLength, text.Length - index);
            string piece = text.Substring(index, length);

            if (index + length < text.Length)
            {
                int lastSpace = piece.LastIndexOf(' ');
                if (lastSpace > 0)
                {
                    length = lastSpace + 1;
                    piece = text.Substring(index, length);
                }
            }

            yield return piece;
            index += length;
        }
    }
}
