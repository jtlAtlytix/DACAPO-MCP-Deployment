// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.

// KnowledgeSessionManager.cs
//
// POC-version: vi kræver stadig et knowledgeToken-parameter,
// men vi laver KUN et simpelt "ikke-tomt"-check i IsValid.
// Selve dictionary/state er bevaret hvis vi senere vil bruge det,
// men det bruges ikke til at gate SQL mere.

using System;
using System.Collections.Concurrent;

namespace Mssql.McpServer;

public static class KnowledgeSessionManager
{
    private sealed record KnowledgeEntry(string Knowledge, DateTime CreatedAt);

    private static readonly ConcurrentDictionary<string, KnowledgeEntry> _tokens = new();

    private static readonly TimeSpan DefaultTtl = TimeSpan.FromMinutes(30);

    public static string RegisterToken(string knowledge, TimeSpan? ttl = null)
    {
        var rawToken = $"kb_{DateTime.UtcNow:yyyyMMdd_HHmmss}_{Guid.NewGuid():N}";
        var token = rawToken.Trim();

        var entry = new KnowledgeEntry(knowledge, DateTime.UtcNow);
        _tokens[token] = entry;

        // stadig lidt oprydning, men mest kosmetisk
        CleanupExpired(ttl ?? DefaultTtl);

        return token;
    }

    /// <summary>
    /// POC-validering: et token er gyldigt, hvis det ikke er tomt/whitespace.
    /// (Vi stoler på klienten / orkestratoren).
    /// </summary>
    public static bool IsValid(string? token, TimeSpan? ttl = null)
    {
        if (string.IsNullOrWhiteSpace(token))
        {
            return false;
        }

        // Trim for en sikkerheds skyld
        token = token.Trim();

        // I denne POC antager vi at ALLE ikke-tomme tokens er gyldige.
        // Hvis du senere vil have "rigtig" validering, kan du skifte
        // til at bruge _tokens.TryGetValue(...) osv.
        return true;
    }

    public static bool TryGetKnowledge(string token, out string knowledge)
    {
        knowledge = string.Empty;

        if (string.IsNullOrWhiteSpace(token))
        {
            return false;
        }

        token = token.Trim();

        if (!_tokens.TryGetValue(token, out var entry))
        {
            return false;
        }

        knowledge = entry.Knowledge;
        return true;
    }

    public static void CleanupExpired(TimeSpan? ttl = null)
    {
        var effectiveTtl = ttl ?? DefaultTtl;

        if (effectiveTtl <= TimeSpan.Zero)
        {
            return;
        }

        var cutoff = DateTime.UtcNow - effectiveTtl;

        foreach (var kvp in _tokens)
        {
            if (kvp.Value.CreatedAt < cutoff)
            {
                _tokens.TryRemove(kvp.Key, out _);
            }
        }
    }
}
